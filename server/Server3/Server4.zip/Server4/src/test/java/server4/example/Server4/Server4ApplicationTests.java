package server4.example.Server4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Server4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
